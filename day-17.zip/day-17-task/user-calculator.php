<!DOCTYPE html>
<html>
    <body>
        <h1>calculator</h1>

        <form method="post">
          first number
          <input type="number" name="number1"><br><br>
          second number
          <input type="number" name="number2"><br><br>
          <input type="submit" name="submit1" value="add">
          <input type="submit" name="submit2" value="subtract">
          <input type="submit" name="submit3" value="multiply">
          <input type="submit" name="submit4" value="divide"><br><br>
        </form>

       <?php

      //  $x = 10;
      //  $y = 5;

      //  $a = $x + $y;
      //  $s = $x - $y;
      //  $m = $x * $y;
      //  $d = $x / $y;

       echo "calculator"."<br>";

       echo "1.addition"."<br>";
       echo "2.substraction"."<br>";
       echo "3.multiplication"."<br>";
       echo "4.division"."<br>";

       if (isset($_POST['submit1'])) {
        $number1=$_POST['number1'];
        $number2=$_POST['number2'];
        $add=$number1+$number2;
        echo "the sum of $number1 and $number2 is:".$add;
       }
       elseif (isset($_POST['submit2'])) {
        $number1=$_POST['number1'];
        $number2=$_POST['number2'];
        $sub=$number1-$number2;
        echo "the subtraction of $number1 and $number2 is:".$sub;
       }
       elseif (isset($_POST['submit3'])) {
        $number1=$_POST['number1'];
        $number2=$_POST['number2'];
        $mul=$number1*$number2;
        echo "the multiplication of $number1 and $number2 is:".$mul;
       }
       elseif (isset($_POST['submit4'])) {
        $number1=$_POST['number1'];
        $number2=$_POST['number2'];
        $div=$number1/$number2;
        echo "the division of $number1 and $number2 is:".$div;
       }
       else {
        echo " ";
      }
    
       ?>
        
    </body>
</html>