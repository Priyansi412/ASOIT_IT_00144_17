<!DOCTYPE html>
<html>
    <body>
        <h1>calculator</h1>
       <?php

       $x = 10;
       $y = 5;

       $a = $x + $y;
       $s = $x - $y;
       $m = $x * $y;
       $d = $x / $y;

       echo "calculator"."<br>";

       echo "1.addition"."<br>";
       echo "2.substraction"."<br>";
       echo "3.multiplication"."<br>";
       echo "4.division"."<br>";

       echo "addition = $a"."<br>";
       echo "substraction = $s"."<br>";
       echo "multiplication = $m"."<br>";
       echo "division = $d"."<br>";

       ?>
        
    </body>
</html>