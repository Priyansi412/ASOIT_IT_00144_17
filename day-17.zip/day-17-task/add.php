<!DOCTYPE html>
<html>
    <body>

        <form method="post">
          first number
          <input type="number" name="number1"><br>
          second number
          <input type="number" name="number2"><br>
          <input type="submit" name="submit" value="add">
        </form>

        <?php
        if (isset($_POST['submit'])) {
            $number1=$_POST['number1'];
            $number2=$_POST['number2'];
            $add=$number1+$number2;
            echo "the sum of $number1 and $number2 is:".$add;
        }
        ?>


        </body>
</html>